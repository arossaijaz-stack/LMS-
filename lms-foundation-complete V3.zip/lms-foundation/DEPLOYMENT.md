# Deployment Guide — Supabase + Netlify

This guide walks through the exact setup for your chosen stack: **Supabase** for the database, **Netlify** for hosting both the backend API (as a serverless function) and the frontend.

---

## Part 1 — Database on Supabase

**Two ways to create the tables, depending on whether you have a machine that can run Node.js/Prisma CLI:**

### Option A — You have Prisma CLI access somewhere (a developer's machine, Claude Code, etc.)

1. Create a project at [supabase.com](https://supabase.com) (free tier is fine to start).
2. Go to **Project Settings → Database**. You need **two** connection strings:
   - **Connection pooling** string (port `6543`, mode: Transaction) — this is your `DATABASE_URL`. Add `?pgbouncer=true` to the end if Supabase doesn't already include it.
   - **Connection string** (port `5432`, direct) — this is your `DIRECT_URL`, used only when running migrations.
3. Put both into `backend/.env`:
   ```
   DATABASE_URL="postgresql://postgres.[project-ref]:[password]@aws-0-[region].pooler.supabase.com:6543/postgres?pgbouncer=true"
   DIRECT_URL="postgresql://postgres.[project-ref]:[password]@aws-0-[region].pooler.supabase.com:5432/postgres"
   ```
4. Run migrations against Supabase (uses `DIRECT_URL` automatically, per the `directUrl` setting in `schema.prisma`):
   ```bash
   cd backend
   pnpm prisma:migrate --name init
   pnpm prisma:seed
   ```

### Option B — No machine to run Prisma CLI (this is your situation)

`schema.prisma` is **not SQL** — it's Prisma's own schema language, and normally `prisma migrate` translates it into real SQL for you. Without Node.js/Prisma CLI available, use the pre-translated SQL instead:

1. Create your Supabase project and get your connection strings, same as steps 1-3 above (you still need these for the backend's `.env`, even though you won't run `prisma migrate` directly).
2. In Supabase Dashboard → **SQL Editor** → New Query, paste the **entire contents** of `database/supabase-init.sql` and click Run. This creates all 27 tables, 8 enums, foreign keys, and indexes — hand-translated to match Prisma's exact conventions.
3. Run `database/supabase-seed-admin.sql` the same way to create your first Admin login (`admin@youracademy.com` / `ChangeMe123!` — change this password after first login) — its bcrypt hash was generated with the same library and settings the backend actually uses, so it works correctly, not a placeholder.
4. **Once you DO get Prisma CLI access later** (a developer joins, or you use Claude Code on a real machine), run `npx prisma migrate resolve --applied "0_init"` against this same database — this tells Prisma "these tables already exist, don't try to recreate them," keeping Prisma's own migration history in sync with what you created by hand. Skipping this step just means Prisma won't know about prior migrations; it won't break the already-working database.

**Why two connection strings either way?** Supabase's pooler (PgBouncer, port 6543) is required for serverless deployments — each Netlify Function invocation can open a fresh connection, and Postgres has a hard connection limit that a normal server wouldn't hit but serverless easily can. PgBouncer's transaction-pooling mode, however, doesn't support the prepared statements Prisma's migration engine needs, so migrations (Option A) must go through the direct connection (port 5432) instead — this is Prisma's officially documented pattern for Supabase.

---

## Part 2 — Backend API on Netlify

The backend deploys as **its own separate Netlify site**, distinct from the frontend site (Part 3). Both live in the same monorepo but deploy independently.

1. In Netlify, create a new site and point it at your repo, with **Base directory** set to `backend`.
2. Netlify will pick up `backend/netlify.toml` automatically. It:
   - Runs `npm install && npx prisma generate && npm run build`
   - Bundles `netlify/functions/api.ts` as a single serverless function
   - Redirects all `/api/*` traffic to that function
3. In **Site Settings → Environment Variables**, add every variable from `backend/.env.example` (Supabase URLs, JWT secrets, payment gateway credentials, `FRONTEND_URL`, etc.) — use real production values, not the placeholder ones.
4. Deploy. Your API will be live at `https://your-backend-site.netlify.app/api`.

### Read this before going live — real tradeoffs of this setup

NestJS is built as a persistent server; Netlify Functions are serverless (spin up per-request, stateless). The wrapper in `netlify/functions/api.ts` makes this work correctly, but with real constraints:

- **Cold starts**: the first request after idle time pays the full app bootstrap cost (roughly 1-3 seconds). The function caches the bootstrapped app across warm invocations to minimize repeat cost, but a cold start is unavoidable on serverless.
- **10-second execution timeout** (Netlify free/Pro tier) — a slow query or a Supabase pooler hiccup could hit this. Fine for this app's typical request shapes; worth monitoring once real traffic starts.
- **No WebSocket/long-polling support** — not used anywhere in this app today, but worth knowing if a future feature (e.g. live-class chat) would need it.

**Honest recommendation:** this setup is genuinely fine for an initial launch and moderate traffic. If the academy grows and you start seeing timeout errors or cold-start complaints, the natural next step is moving the backend to a persistent-process host (Railway, Render, or Fly.io — all have straightforward NestJS deployment paths) while keeping the frontend on Netlify, which is what Netlify is actually built for. Nothing about the application code needs to change for that move — only where it's hosted.

---

## Part 3 — Frontend on Netlify

(This assumes the Next.js frontend app has been built per the Phase 0 monorepo structure — `apps/web`.)

1. Create a second Netlify site, **Base directory** set to `apps/web` (or wherever the Next.js app lives).
2. Netlify's Next.js Runtime handles the build automatically (`@netlify/plugin-nextjs` — Netlify auto-detects and installs this for Next.js sites).
3. Set `NEXT_PUBLIC_API_BASE_URL` to your deployed backend URL from Part 2 (e.g. `https://your-backend-site.netlify.app`).
4. Deploy.

---

## Part 4 — Post-deploy checklist

- [ ] `GET https://your-backend-site.netlify.app/api/health` returns `{"status":"ok"}`
- [ ] `GET https://your-backend-site.netlify.app/api/health/ready` returns `{"status":"ok","database":"connected"}` — confirms Supabase connectivity from the deployed function
- [ ] Login with the seeded admin account works end-to-end through the real deployed URL
- [ ] **Set real webhook secrets** (`STRIPE_WEBHOOK_SECRET`, `JAZZCASH_INTEGRITY_SALT`, `EASYPAISA_HASH_KEY`) in Netlify's environment variables before connecting real payment gateways — Phase 10 made `PaymentProviderService` fail closed (reject all webhooks) in production if these aren't set, specifically so a misconfigured deploy can't silently accept fake payment webhooks
- [ ] Point your payment gateway's webhook configuration at `https://your-backend-site.netlify.app/api/payments/webhook`
- [ ] Set up uptime monitoring (UptimeRobot, Better Stack, or similar) pinging `/api/health` every few minutes
- [ ] Confirm CORS: `FRONTEND_URL` env var on the backend matches your actual deployed frontend URL exactly

---

## Local development (unchanged)

Local dev still works exactly as documented in each phase's README — point `DATABASE_URL` at a local Postgres via Docker (Phase 0's `docker-compose.yml` pattern) or directly at your Supabase instance if you prefer developing against the real database from day one.
