import { apiFetch, clearTokens } from './api-client';

export interface AuthUser {
  id: string;
  email: string;
  role: 'STUDENT' | 'TEACHER' | 'CAMPUS_MANAGER' | 'ADMIN' | 'SUPPORT' | 'FINANCE';
  tenantId: string | null;
}

interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  user: AuthUser;
}

function persistAuth(response: AuthResponse) {
  window.localStorage.setItem('accessToken', response.accessToken);
  window.localStorage.setItem('refreshToken', response.refreshToken);
  window.localStorage.setItem('user', JSON.stringify(response.user));
}

export async function login(email: string, password: string): Promise<AuthUser> {
  const response = await apiFetch<AuthResponse>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
    skipAuth: true,
  });
  persistAuth(response);
  return response.user;
}

export async function register(fullName: string, email: string, password: string): Promise<AuthUser> {
  const response = await apiFetch<AuthResponse>('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ fullName, email, password }),
    skipAuth: true,
  });
  persistAuth(response);
  return response.user;
}

export function logout() {
  clearTokens();
}

export function getCurrentUser(): AuthUser | null {
  if (typeof window === 'undefined') return null;
  const raw = window.localStorage.getItem('user');
  return raw ? JSON.parse(raw) : null;
}

export function isAuthenticated(): boolean {
  if (typeof window === 'undefined') return false;
  return !!window.localStorage.getItem('accessToken');
}
