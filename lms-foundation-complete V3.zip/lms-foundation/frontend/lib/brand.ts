import { API_BASE_URL } from './api-client';

export interface BrandSettings {
  academyName: string;
  logoUrl: string | null;
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;
  heroTitle: string | null;
  heroSubtitle: string | null;
  heroImageUrl: string | null;
}

const FALLBACK: BrandSettings = {
  academyName: 'Your Academy',
  logoUrl: null,
  primaryColor: '#2A5CAA',
  secondaryColor: '#E0A526',
  fontFamily: 'Space Grotesk',
  heroTitle: null,
  heroSubtitle: null,
  heroImageUrl: null,
};

// Runs on the server (in layout.tsx, a Server Component) so the CSS
// variables are already correct in the initial HTML — no flash of
// default colors before a client-side fetch resolves, unlike the
// client-only reference pattern in Phase 9's applyBrandSettings.ts.
export async function getBrandSettings(): Promise<BrandSettings> {
  try {
    const response = await fetch(`${API_BASE_URL}/api/brand-settings`, {
      next: { revalidate: 60 }, // re-fetch at most once a minute — an admin's branding change shows up within a minute, not instantly, but never hammers the API on every page load
    });
    if (!response.ok) return FALLBACK;
    return await response.json();
  } catch {
    return FALLBACK;
  }
}
