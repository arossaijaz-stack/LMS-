const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:4000';

export class ApiError extends Error {
  constructor(public status: number, public body: any) {
    super(body?.message ?? `Request failed with status ${status}`);
  }
}

interface FetchOptions extends RequestInit {
  skipAuth?: boolean;
}

// Client-side only — reads the access token from localStorage and
// attaches it automatically. Server Components that need public data
// (course catalog, brand settings) should use the plain `fetch` with
// `${API_BASE_URL}/api/...` directly instead, since localStorage isn't
// available during SSR.
export async function apiFetch<T = any>(path: string, options: FetchOptions = {}): Promise<T> {
  const { skipAuth, ...init } = options;
  const headers = new Headers(init.headers);
  headers.set('Content-Type', 'application/json');

  if (!skipAuth && typeof window !== 'undefined') {
    const token = window.localStorage.getItem('accessToken');
    if (token) headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(`${API_BASE_URL}/api${path}`, { ...init, headers });

  if (response.status === 401 && !skipAuth && typeof window !== 'undefined') {
    const refreshed = await tryRefreshToken();
    if (refreshed) {
      headers.set('Authorization', `Bearer ${refreshed}`);
      const retry = await fetch(`${API_BASE_URL}/api${path}`, { ...init, headers });
      return parseResponse<T>(retry);
    }
    clearTokens();
  }

  return parseResponse<T>(response);
}

async function parseResponse<T>(response: Response): Promise<T> {
  const isJson = response.headers.get('content-type')?.includes('application/json');
  const body = isJson ? await response.json() : null;
  if (!response.ok) throw new ApiError(response.status, body);
  return body as T;
}

async function tryRefreshToken(): Promise<string | null> {
  const refreshToken = window.localStorage.getItem('refreshToken');
  if (!refreshToken) return null;

  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/refresh`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${refreshToken}` },
    });
    if (!response.ok) return null;
    const data = await response.json();
    window.localStorage.setItem('accessToken', data.accessToken);
    window.localStorage.setItem('refreshToken', data.refreshToken);
    return data.accessToken;
  } catch {
    return null;
  }
}

export function clearTokens() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem('accessToken');
  window.localStorage.removeItem('refreshToken');
  window.localStorage.removeItem('user');
}

export { API_BASE_URL };
