/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**' }, // logos/thumbnails come from Bunny/S3 per-academy — host varies by deployment
    ],
  },
};

module.exports = nextConfig;
