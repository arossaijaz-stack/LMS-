import { getBrandSettings } from '@/lib/brand';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Hero } from '@/components/marketing/Hero';
import { ProgramGrid } from '@/components/marketing/ProgramGrid';

export default async function HomePage() {
  const brand = await getBrandSettings();

  return (
    <>
      <Navbar brand={brand} />
      <main>
        <Hero brand={brand} />
        <ProgramGrid />
      </main>
      <Footer brand={brand} />
    </>
  );
}
