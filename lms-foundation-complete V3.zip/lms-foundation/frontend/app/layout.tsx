import type { Metadata } from 'next';
import { getBrandSettings } from '@/lib/brand';

// Self-hosted fonts (Fontsource, distributed via npm) instead of
// next/font/google's live Google Fonts CDN fetch. This is a deliberate
// choice, not just a workaround: it removes a runtime dependency on
// Google's CDN entirely (no cross-origin font request on every visitor's
// first load, works in fully offline/air-gapped CI environments, and
// sidesteps any GDPR/privacy concern some clients have about Google
// Fonts). The font files ship inside node_modules and get bundled by
// Next.js like any other static asset.
import '@fontsource/space-grotesk/500.css';
import '@fontsource/space-grotesk/600.css';
import '@fontsource/space-grotesk/700.css';
import '@fontsource/ibm-plex-sans/400.css';
import '@fontsource/ibm-plex-sans/500.css';
import '@fontsource/ibm-plex-sans/600.css';
import './globals.css';

export async function generateMetadata(): Promise<Metadata> {
  const brand = await getBrandSettings();
  return {
    title: brand.academyName,
    description: `Learn with ${brand.academyName} — live classes, practice tests, and expert teachers.`,
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const brand = await getBrandSettings();

  // Injected as an inline style on <html> so the correct brand colors are
  // present in the very first byte of HTML — no flash of default colors
  // while a client-side fetch resolves.
  const brandStyle = {
    '--color-primary': brand.primaryColor,
    '--color-secondary': brand.secondaryColor,
  } as React.CSSProperties;

  return (
    <html lang="en" style={brandStyle}>
      <body className="font-base">{children}</body>
    </html>
  );
}
