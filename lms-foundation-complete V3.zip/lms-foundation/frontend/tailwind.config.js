/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "../../packages/ui/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Brand colors — overridden at runtime from BrandSettings (Phase 9)
        primary: {
          DEFAULT: "var(--color-primary)",
          hover: "var(--color-primary-hover)",
        },
        secondary: {
          DEFAULT: "var(--color-secondary)",
          hover: "var(--color-secondary-hover)",
        },
        ink: "var(--color-ink)",
        paper: "var(--color-paper)",
        surface: "var(--color-surface)",
        border: "var(--color-border)",
        success: "var(--color-success)",
        error: "var(--color-error)",
        warning: "var(--color-warning)",
        // Fixed subject-accent palette (Phase 0 principle: brand colors are
        // configurable, but subject/program color-coding is a structural
        // design device, not a brand choice — kept constant across
        // academies so the "timetable" system always reads consistently).
        subject: {
          math: "#2A5CAA",
          science: "#2F8F5B",
          english: "#B54B8C",
          test: "#E0A526",
          coaching: "#D65F4C",
        },
      },
      textColor: {
        primary: "var(--color-text-primary)",
        secondary: "var(--color-text-secondary)",
      },
      fontFamily: {
        display: ["var(--font-display-family)", "sans-serif"],
        base: ["var(--font-body-family)", "sans-serif"],
      },
      borderRadius: {
        sm: "var(--radius-sm)",
        md: "var(--radius-md)",
        lg: "var(--radius-lg)",
      },
      maxWidth: {
        prose: "68ch",
      },
    },
  },
  plugins: [],
};

