// Reference implementation: fetches BrandSettings from the backend
// (Phase 9's GET /api/brand-settings) and injects them as CSS variables
// at runtime, overriding the static defaults in tokens.css.
//
// Call this once on app load (e.g. in a root layout's useEffect, or as
// a server-side fetch + inline <style> tag for zero-flash SSR — the
// latter is preferable once the actual Next.js app exists, since this
// client-side version will show default colors for a moment before the
// fetch resolves).

export interface BrandSettings {
  academyName: string;
  logoUrl: string | null;
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;
  heroTitle: string | null;
  heroSubtitle: string | null;
  heroImageUrl: string | null;
}

// Lightens/darkens a hex color by a percentage — used to derive the
// "-hover" variants (--color-primary-hover etc.) from the single
// primaryColor/secondaryColor an admin picks, so they only ever have to
// choose ONE color per role, not two.
function shade(hex: string, percent: number): string {
  const num = parseInt(hex.replace('#', ''), 16);
  const amt = Math.round(2.55 * percent);
  const r = Math.max(0, Math.min(255, (num >> 16) + amt));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0x00ff) + amt));
  const b = Math.max(0, Math.min(255, (num & 0x0000ff) + amt));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

export function applyBrandSettings(settings: BrandSettings) {
  const root = document.documentElement.style;

  root.setProperty('--color-primary', settings.primaryColor);
  root.setProperty('--color-primary-hover', shade(settings.primaryColor, -10));
  root.setProperty('--color-secondary', settings.secondaryColor);
  root.setProperty('--color-secondary-hover', shade(settings.secondaryColor, -10));
  root.setProperty('--font-family-base', `'${settings.fontFamily}', sans-serif`);
}

// Example usage in a Next.js client component:
//
//   useEffect(() => {
//     fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/api/brand-settings`)
//       .then((res) => res.json())
//       .then(applyBrandSettings);
//   }, []);
