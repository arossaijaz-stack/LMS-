import type { BrandSettings } from '@/lib/brand';

export function Footer({ brand }: { brand: BrandSettings }) {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto max-w-6xl px-6 py-10 text-sm text-secondary">
        <p>© {new Date().getFullYear()} {brand.academyName}. All rights reserved.</p>
      </div>
    </footer>
  );
}
