import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import type { BrandSettings } from '@/lib/brand';

export function Navbar({ brand }: { brand: BrandSettings }) {
  return (
    <header className="border-b border-border">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="font-display text-xl font-semibold text-ink">
          {brand.academyName}
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          <Link href="/#programs" className="text-[15px] text-secondary hover:text-ink">
            Programs
          </Link>
          <Link href="/#results" className="text-[15px] text-secondary hover:text-ink">
            Results
          </Link>
          <Link href="/#faq" className="text-[15px] text-secondary hover:text-ink">
            FAQs
          </Link>
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/login" className="text-[15px] font-medium text-ink hover:text-primary">
            Log in
          </Link>
          <Link href="/register">
            <Button size="md">Enroll now</Button>
          </Link>
        </div>
      </div>
    </header>
  );
}
