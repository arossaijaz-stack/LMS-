const PROGRAMS = [
  {
    name: 'Matric & FSc Coaching',
    description: 'Chapter-wise video lectures, past-paper practice, and weekly tests aligned to your board.',
    border: 'border-l-subject-math',
  },
  {
    name: 'Entry Test Prep',
    description: 'MDCAT, ECAT, and NTS preparation with full-length timed mocks and topic-wise breakdowns.',
    border: 'border-l-subject-test',
  },
  {
    name: 'O & A Levels',
    description: 'Cambridge and Edexcel syllabus coverage with past papers from every recent session.',
    border: 'border-l-subject-science',
  },
  {
    name: 'Foreign Test Prep',
    description: 'SAT and IELTS classes built around the sections students actually lose marks on.',
    border: 'border-l-subject-coaching',
  },
];

export function ProgramGrid() {
  return (
    <section id="programs" className="mx-auto max-w-6xl px-6 py-16 md:py-24">
      <h2 className="font-display text-3xl font-semibold text-ink">Pick a program</h2>
      <p className="mt-2 max-w-lg text-secondary">
        Every program includes live classes, recorded lectures you can rewatch, and a teacher assigned to your batch.
      </p>

      <div className="mt-10 grid gap-px overflow-hidden border border-border bg-border sm:grid-cols-2">
        {PROGRAMS.map((program) => (
          <div key={program.name} className={`border-l-4 bg-white p-6 ${program.border}`}>
            <h3 className="font-display text-lg font-semibold text-ink">{program.name}</h3>
            <p className="mt-2 text-[15px] text-secondary">{program.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
