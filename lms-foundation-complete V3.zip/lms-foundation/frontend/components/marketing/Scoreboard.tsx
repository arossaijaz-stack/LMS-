import { CountUp } from './CountUp';

const SUBJECT_BORDER_CLASS: Record<string, string> = {
  math: 'border-l-subject-math',
  science: 'border-l-subject-science',
  test: 'border-l-subject-test',
  coaching: 'border-l-subject-coaching',
};

const STATS = [
  { label: 'Students enrolled', value: 42000, suffix: '+', subject: 'math' },
  { label: 'Average score improvement', value: 23, suffix: '%', subject: 'science' },
  { label: 'Pass rate, entry tests', value: 94, suffix: '%', subject: 'test' },
  { label: 'Live classes every week', value: 380, suffix: '', subject: 'coaching' },
];

// Styled like an actual mark sheet — a left border per row (the same
// "subject color" device used for program cards), tabular numbers set
// large in the display face. Deliberately NOT a grid of identical
// rounded cards with soft shadows.
export function Scoreboard() {
  return (
    <div className="w-full border border-border bg-white">
      {STATS.map((stat, i) => (
        <div
          key={stat.label}
          className={`flex items-center justify-between border-l-4 px-5 py-4 ${SUBJECT_BORDER_CLASS[stat.subject]} ${
            i !== STATS.length - 1 ? 'border-b border-b-border' : ''
          }`}
        >
          <span className="text-[15px] text-secondary">{stat.label}</span>
          <span className="font-display text-2xl font-semibold text-ink">
            <CountUp to={stat.value} />
            {stat.suffix}
          </span>
        </div>
      ))}
    </div>
  );
}
