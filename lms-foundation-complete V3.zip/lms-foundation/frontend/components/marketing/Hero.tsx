import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { Scoreboard } from './Scoreboard';
import type { BrandSettings } from '@/lib/brand';

export function Hero({ brand }: { brand: BrandSettings }) {
  return (
    <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
      <div className="grid gap-12 md:grid-cols-2 md:items-center md:gap-16">
        <div>
          <h1 className="max-w-lg font-display text-4xl font-semibold leading-[1.1] text-ink md:text-5xl">
            {brand.heroTitle ?? 'Study for your boards and entry tests with teachers who know the paper.'}
          </h1>
          <p className="mt-5 max-w-md text-lg text-secondary">
            {brand.heroSubtitle ??
              'Live classes, unlimited practice tests, and a teacher who replies when you\u2019re stuck at 11pm.'}
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link href="/register">
              <Button size="lg">Enroll now</Button>
            </Link>
            <Link href="#programs">
              <Button size="lg" variant="ghost">
                See our programs
              </Button>
            </Link>
          </div>
        </div>

        <Scoreboard />
      </div>
    </section>
  );
}
