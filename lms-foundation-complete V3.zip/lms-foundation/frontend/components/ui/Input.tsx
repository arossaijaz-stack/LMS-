import { InputHTMLAttributes, forwardRef } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, id, className = '', ...props }, ref) => {
    const inputId = id ?? props.name;
    return (
      <div className="flex flex-col gap-1.5">
        <label htmlFor={inputId} className="text-sm font-medium text-primary">
          {label}
        </label>
        <input
          ref={ref}
          id={inputId}
          className={`w-full rounded-sm border bg-white px-3.5 py-2.5 text-[15px] text-ink placeholder:text-secondary/60 focus:border-primary focus:outline-none ${
            error ? 'border-error' : 'border-border'
          } ${className}`}
          {...props}
        />
        {error && <span className="text-sm text-error">{error}</span>}
      </div>
    );
  },
);
Input.displayName = 'Input';
