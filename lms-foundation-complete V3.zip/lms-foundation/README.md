# LMS Project — Phase 0: Foundation & Planning

This document records the architecture decisions made in Phase 0. Every later phase builds on top of this — don't skip re-reading it before starting Phase 1.

---

## 1. Tech Stack Decision

| Layer | Choice | Why |
|---|---|---|
| Frontend (Marketing + Student Portal) | **Next.js 14 (App Router) + TypeScript + Tailwind CSS** | SSR for SEO on marketing pages, file-based routing, huge ecosystem, easy to theme via Tailwind config + CSS variables |
| Admin Panel | **Same Next.js app, separate `/admin` route group** (or separate app in the monorepo if it grows large) | Shared component library, shared auth, less duplication |
| Backend API | **Node.js + NestJS + TypeScript** | Structured, modular (matches our phase-wise module approach), built-in support for RBAC guards, DI, and clean separation of concerns |
| Database | **PostgreSQL** | Relational integrity for users/enrollments/payments; JSON columns available for flexible content blocks |
| ORM | **Prisma** | Type-safe queries, easy migrations, great DX with NestJS |
| Auth | **JWT (access + refresh tokens)** | Stateless, scales well, works cleanly across web + future mobile app |
| Video Storage/CDN | **Bunny.net Stream** (or Cloudflare Stream as alternative) | Cheap for Pakistan-heavy traffic, built-in adaptive streaming, signed URLs to prevent piracy |
| File Storage (readings, assignments, avatars) | **AWS S3 / Backblaze B2** | Cheap object storage, works with signed URLs |
| Payments | **JazzCash + Easypaisa (local) + Stripe (international, optional)** | Matches Pakistani market like KIPS |
| Live Classes | **Zoom API** (fastest to integrate) — Jitsi self-hosted as a cost-saving alternative later | Zoom has the most mature SDK/API for scheduling + recordings |
| Notifications | **Email (Resend/SendGrid) + in-app** first; WhatsApp/SMS (Twilio or local gateway) added later | Keep Phase 6 lean; expand later without breaking architecture |
| Hosting | **Backend + DB: Railway or a VPS (Hetzner/DigitalOcean)**. **Frontend: Vercel** | Cheap to start, scales as academy grows; Vercel gives free SSR hosting for Next.js |

> **Note:** This stack is a strong default recommendation. If your team already has strength in a different stack (e.g., Laravel/PHP), swap the backend row — the module roadmap (Phase 1–10) stays valid regardless of stack.

---

## 2. Repo Structure (Monorepo)

```
lms-project/
├── apps/
│   ├── web/              # Next.js — marketing site + student portal + admin panel
│   └── mobile/            # (Phase 11, later) React Native, shares API with web
├── services/
│   └── api/               # NestJS backend
│       ├── src/
│       │   ├── modules/
│       │   │   ├── auth/
│       │   │   ├── users/
│       │   │   ├── programs/
│       │   │   ├── courses/
│       │   │   ├── enrollments/
│       │   │   ├── quizzes/
│       │   │   ├── assignments/
│       │   │   ├── live-classes/
│       │   │   ├── payments/
│       │   │   ├── notifications/
│       │   │   └── theming/
│       │   └── main.ts
│       └── prisma/
│           └── schema.prisma
├── packages/
│   ├── ui/                 # Shared component library (buttons, cards, etc. — themeable)
│   └── config/              # Shared TS/ESLint/Tailwind config
├── docs/
│   ├── ERD.md
│   └── decisions/           # Architecture Decision Records (one .md per big decision)
└── docker-compose.yml       # Local Postgres + Redis for dev
```

**Why monorepo:** courses/theming/auth logic will be shared between web and (later) mobile. A monorepo (using Turborepo or Nx) avoids duplicating types and business logic.

---

## 3. Environment Setup

See `backend/.env.example` and `frontend/.env.example` in this folder. Copy each to `.env` and fill in real values before running locally.

Local dev dependencies:
- Docker (for Postgres + Redis locally)
- Node.js 20+
- pnpm (recommended for monorepo workspace efficiency)

---

## 4. Design System Foundation (feeds into Phase 9 — Theming)

Decided now, so we never have to retrofit:

- All colors, fonts, and spacing are defined as **CSS variables**, not hardcoded Tailwind classes directly in components.
- Tailwind config reads from these CSS variables (see `frontend/theme/tokens.css`).
- Every brand-specific value (logo URL, primary color, hero banner image, academy name) will eventually live in a `BrandSettings` database table (built in Phase 9), fetched at runtime and injected as CSS variables.
- Component library (`packages/ui`) is built to consume tokens, never fixed colors — e.g., a `<Button>` uses `bg-primary`, not `bg-blue-600`.

---

## 5. Hosting/Infra Decision

**Recommended starting setup (cheap, scales fine for a single academy):**
- Frontend: Vercel (free tier to start)
- Backend: Railway (simple deploys, managed Postgres included) — or a $10–20/month Hetzner VPS if you want more control
- Video: Bunny.net Stream (pay-as-you-go, cheap storage+delivery)
- File storage: Backblaze B2 (cheapest S3-compatible option)
- Domain + SSL: any registrar + Cloudflare (free SSL, DNS, basic DDoS protection)

This can scale to multi-tenant/multi-academy later without a rebuild — just add a `tenant_id` column pattern (already reflected in the schema, see `database/schema.prisma`).

---

## 6. What's Next

Proceed to **Phase 1 — Authentication & User Management** using the schema and repo structure defined here as the base.
