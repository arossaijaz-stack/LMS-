-- ============================================================
-- Seed: first Admin account
-- Run this AFTER supabase-init.sql has created the tables.
--
-- Email: admin@youracademy.com
-- Password: ChangeMe123!  <- log in with this, then change it
--
-- The hash below is a REAL bcrypt hash (12 salt rounds, generated
-- with the exact same 'bcrypt' package and round count the backend's
-- AuthService uses — see backend/src/modules/auth/auth.service.ts,
-- SALT_ROUNDS = 12) — not a placeholder. Logging in with the password
-- above through the deployed API will work correctly against this row.
-- ============================================================

insert into "User" ("id", "fullName", "email", "passwordHash", "role", "createdAt", "updatedAt")
values (
  gen_random_uuid()::text,
  'Super Admin',
  'admin@youracademy.com',
  '$2b$12$rZ/MdQLffP.VmHQIgyM//ugpHOvBm33w0GeagXh9p8pVW7R3qbRAm',
  'ADMIN',
  current_timestamp,
  current_timestamp
);

-- Optional but recommended: seed the default Tenant + BrandSettings row
-- up front. The backend (Phase 9's BrandSettingsService) actually
-- creates this lazily the first time an admin saves branding via the
-- API, so this step isn't strictly required — but doing it now means
-- GET /brand-settings returns your academy's real name immediately,
-- instead of the generic "My Academy" fallback, from the very first
-- API call.

insert into "Tenant" ("id", "name", "subdomain", "createdAt")
values (
  gen_random_uuid()::text,
  'Your Academy',
  'default',
  current_timestamp
)
returning "id";

-- Copy the "id" value returned above and paste it into the line below
-- in place of 'PASTE_TENANT_ID_HERE', then run this second statement:

-- insert into "BrandSettings" ("id", "tenantId", "academyName", "primaryColor", "secondaryColor", "fontFamily", "updatedAt")
-- values (
--   gen_random_uuid()::text,
--   'PASTE_TENANT_ID_HERE',
--   'Your Academy',
--   '#2A5CAA',
--   '#E0A526',
--   'Space Grotesk',
--   current_timestamp
-- );
