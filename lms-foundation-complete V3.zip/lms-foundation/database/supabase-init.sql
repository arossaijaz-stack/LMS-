-- ============================================================
-- LMS — Full database schema, hand-translated from
-- backend/prisma/schema.prisma into raw PostgreSQL SQL.
--
-- WHY THIS FILE EXISTS: schema.prisma is NOT SQL — it's Prisma's own
-- schema language, normally translated into real SQL by running
-- `npx prisma migrate dev` on a machine with Node.js. Since you don't
-- have a local machine to run that command, this file is the
-- equivalent SQL, written by hand to match Prisma's exact naming and
-- type-mapping conventions, so `prisma migrate resolve` (see the note
-- at the very bottom) can later mark it as already-applied without
-- conflicts once you DO have Prisma CLI access somewhere.
--
-- HOW TO USE: Paste this entire file into Supabase's SQL Editor
-- (Dashboard → SQL Editor → New Query) and click Run. It's safe to
-- run once against a fresh database. Do not run it twice without
-- dropping the tables first — it will error on the second run because
-- everything already exists (that's expected and fine).
-- ============================================================

-- gen_random_uuid() is built into Postgres 13+ (which Supabase runs),
-- but this extension creation is included defensively — it's a no-op
-- if already available, and guarantees the function exists regardless.
create extension if not exists pgcrypto;

-- ------------------- ENUMS -------------------

create type "UserRole" as enum ('STUDENT', 'TEACHER', 'CAMPUS_MANAGER', 'ADMIN', 'SUPPORT', 'FINANCE');
create type "PricingType" as enum ('MONTHLY', 'LUMP_SUM');
create type "LessonType" as enum ('VIDEO', 'READING', 'QUIZ', 'ASSIGNMENT');
create type "EnrollmentStatus" as enum ('ACTIVE', 'EXPIRED', 'PENDING', 'TRANSFERRED');
create type "TransferRequestStatus" as enum ('PENDING', 'APPROVED', 'REJECTED');
create type "QuestionType" as enum ('SINGLE_CHOICE', 'MULTI_CHOICE', 'OPEN_ENDED');
create type "PaymentStatus" as enum ('PENDING', 'SUCCESS', 'FAILED', 'REFUNDED');
create type "TicketStatus" as enum ('OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED');

-- ------------------- TENANT -------------------

create table "Tenant" (
  "id" text primary key default gen_random_uuid()::text,
  "name" text not null,
  "subdomain" text not null unique,
  "createdAt" timestamp(3) not null default current_timestamp
);

-- ------------------- CAMPUS -------------------

create table "Campus" (
  "id" text primary key default gen_random_uuid()::text,
  "name" text not null,
  "address" text
);

-- ------------------- USER -------------------

create table "User" (
  "id" text primary key default gen_random_uuid()::text,
  "tenantId" text references "Tenant"("id"),
  "fullName" text not null,
  "email" text not null unique,
  "phone" text,
  "passwordHash" text not null,
  "role" "UserRole" not null default 'STUDENT',
  "avatarUrl" text,
  "campusId" text references "Campus"("id"),
  "createdAt" timestamp(3) not null default current_timestamp,
  "updatedAt" timestamp(3) not null default current_timestamp
);
create index "User_tenantId_idx" on "User"("tenantId");
create index "User_campusId_idx" on "User"("campusId");

-- ------------------- PROGRAM -------------------

create table "Program" (
  "id" text primary key default gen_random_uuid()::text,
  "tenantId" text references "Tenant"("id"),
  "name" text not null,
  "slug" text not null unique,
  "description" text,
  "iconUrl" text
);
create index "Program_tenantId_idx" on "Program"("tenantId");

-- ------------------- COURSE -------------------

create table "Course" (
  "id" text primary key default gen_random_uuid()::text,
  "programId" text not null references "Program"("id"),
  "title" text not null,
  "description" text,
  "thumbnailUrl" text,
  "durationText" text,
  "pricingType" "PricingType" not null,
  "price" decimal(65,30) not null,
  "teacherId" text references "User"("id"),
  "isFreeTrial" boolean not null default false,
  "isPublished" boolean not null default false,
  "createdAt" timestamp(3) not null default current_timestamp
);
create index "Course_programId_idx" on "Course"("programId");
create index "Course_teacherId_idx" on "Course"("teacherId");

-- ------------------- SUBJECT -------------------

create table "Subject" (
  "id" text primary key default gen_random_uuid()::text,
  "courseId" text not null references "Course"("id"),
  "title" text not null,
  "order" integer not null default 0
);
create index "Subject_courseId_idx" on "Subject"("courseId");

-- ------------------- CHAPTER -------------------

create table "Chapter" (
  "id" text primary key default gen_random_uuid()::text,
  "subjectId" text not null references "Subject"("id"),
  "title" text not null,
  "order" integer not null default 0
);
create index "Chapter_subjectId_idx" on "Chapter"("subjectId");

-- ------------------- QUIZ -------------------

create table "Quiz" (
  "id" text primary key default gen_random_uuid()::text,
  "title" text not null,
  "timeLimitMin" integer,
  "randomize" boolean not null default false
);

-- ------------------- ASSIGNMENT -------------------

create table "Assignment" (
  "id" text primary key default gen_random_uuid()::text,
  "title" text not null,
  "instructions" text,
  "dueDate" timestamp(3)
);

-- ------------------- LESSON -------------------

create table "Lesson" (
  "id" text primary key default gen_random_uuid()::text,
  "chapterId" text not null references "Chapter"("id"),
  "title" text not null,
  "type" "LessonType" not null,
  "order" integer not null default 0,
  "videoUrl" text,
  "readingBody" text,
  "quizId" text unique references "Quiz"("id"),
  "assignmentId" text unique references "Assignment"("id")
);
create index "Lesson_chapterId_idx" on "Lesson"("chapterId");

-- ------------------- QUESTION -------------------

create table "Question" (
  "id" text primary key default gen_random_uuid()::text,
  "quizId" text not null references "Quiz"("id"),
  "text" text not null,
  "type" "QuestionType" not null,
  "options" jsonb,
  "correctAnswer" text,
  "order" integer not null default 0
);
create index "Question_quizId_idx" on "Question"("quizId");

-- ------------------- ENROLLMENT -------------------

create table "Enrollment" (
  "id" text primary key default gen_random_uuid()::text,
  "userId" text not null references "User"("id"),
  "courseId" text not null references "Course"("id"),
  "status" "EnrollmentStatus" not null default 'PENDING',
  "startedAt" timestamp(3) not null default current_timestamp,
  "expiresAt" timestamp(3),
  unique ("userId", "courseId")
);
create index "Enrollment_courseId_idx" on "Enrollment"("courseId");

-- ------------------- TRANSFER REQUEST -------------------

create table "TransferRequest" (
  "id" text primary key default gen_random_uuid()::text,
  "enrollmentId" text not null references "Enrollment"("id"),
  "requestedCourseId" text not null references "Course"("id"),
  "reason" text,
  "status" "TransferRequestStatus" not null default 'PENDING',
  "reviewedById" text references "User"("id"),
  "createdAt" timestamp(3) not null default current_timestamp,
  "reviewedAt" timestamp(3)
);
create index "TransferRequest_enrollmentId_idx" on "TransferRequest"("enrollmentId");
create index "TransferRequest_requestedCourseId_idx" on "TransferRequest"("requestedCourseId");

-- ------------------- QUIZ ATTEMPT -------------------

create table "QuizAttempt" (
  "id" text primary key default gen_random_uuid()::text,
  "quizId" text not null references "Quiz"("id"),
  "userId" text not null references "User"("id"),
  "answers" jsonb not null,
  "score" decimal(65,30),
  "startedAt" timestamp(3) not null default current_timestamp,
  "submittedAt" timestamp(3)
);
create index "QuizAttempt_quizId_idx" on "QuizAttempt"("quizId");
create index "QuizAttempt_userId_idx" on "QuizAttempt"("userId");

-- ------------------- ASSIGNMENT SUBMISSION -------------------

create table "AssignmentSubmission" (
  "id" text primary key default gen_random_uuid()::text,
  "assignmentId" text not null references "Assignment"("id"),
  "userId" text not null references "User"("id"),
  "fileUrl" text not null,
  "grade" decimal(65,30),
  "feedback" text,
  "submittedAt" timestamp(3) not null default current_timestamp
);
create index "AssignmentSubmission_assignmentId_idx" on "AssignmentSubmission"("assignmentId");
create index "AssignmentSubmission_userId_idx" on "AssignmentSubmission"("userId");

-- ------------------- BATCH -------------------

create table "Batch" (
  "id" text primary key default gen_random_uuid()::text,
  "courseId" text not null references "Course"("id"),
  "name" text not null,
  "startDate" timestamp(3) not null,
  "endDate" timestamp(3)
);
create index "Batch_courseId_idx" on "Batch"("courseId");

-- ------------------- BATCH STUDENT -------------------

create table "BatchStudent" (
  "id" text primary key default gen_random_uuid()::text,
  "batchId" text not null references "Batch"("id"),
  "userId" text not null references "User"("id"),
  unique ("batchId", "userId")
);
create index "BatchStudent_userId_idx" on "BatchStudent"("userId");

-- ------------------- LIVE SESSION -------------------

create table "LiveSession" (
  "id" text primary key default gen_random_uuid()::text,
  "batchId" text not null references "Batch"("id"),
  "title" text not null,
  "scheduledAt" timestamp(3) not null,
  "zoomJoinUrl" text,
  "recordingUrl" text,
  "attendance" jsonb
);
create index "LiveSession_batchId_idx" on "LiveSession"("batchId");

-- ------------------- NOTE / BOOKMARK -------------------

create table "NoteBookmark" (
  "id" text primary key default gen_random_uuid()::text,
  "userId" text not null references "User"("id"),
  "lessonId" text not null references "Lesson"("id"),
  "type" text not null,
  "content" text,
  "createdAt" timestamp(3) not null default current_timestamp
);
create index "NoteBookmark_userId_idx" on "NoteBookmark"("userId");
create index "NoteBookmark_lessonId_idx" on "NoteBookmark"("lessonId");

-- ------------------- LESSON PROGRESS -------------------

create table "LessonProgress" (
  "id" text primary key default gen_random_uuid()::text,
  "userId" text not null references "User"("id"),
  "lessonId" text not null references "Lesson"("id"),
  "completed" boolean not null default false,
  "completedAt" timestamp(3),
  "updatedAt" timestamp(3) not null default current_timestamp,
  unique ("userId", "lessonId")
);
create index "LessonProgress_lessonId_idx" on "LessonProgress"("lessonId");

-- ------------------- NOTIFICATION -------------------

create table "Notification" (
  "id" text primary key default gen_random_uuid()::text,
  "userId" text not null references "User"("id"),
  "title" text not null,
  "body" text not null,
  "isRead" boolean not null default false,
  "createdAt" timestamp(3) not null default current_timestamp
);
create index "Notification_userId_idx" on "Notification"("userId");

-- ------------------- COUPON -------------------

create table "Coupon" (
  "id" text primary key default gen_random_uuid()::text,
  "code" text not null unique,
  "discountPercent" integer,
  "discountAmount" decimal(65,30),
  "maxUses" integer,
  "usedCount" integer not null default 0,
  "expiresAt" timestamp(3),
  "isActive" boolean not null default true,
  "createdAt" timestamp(3) not null default current_timestamp
);

-- ------------------- PAYMENT -------------------

create table "Payment" (
  "id" text primary key default gen_random_uuid()::text,
  "userId" text not null references "User"("id"),
  "courseId" text references "Course"("id"),
  "enrollmentId" text references "Enrollment"("id"),
  "couponId" text references "Coupon"("id"),
  "amount" decimal(65,30) not null,
  "currency" text not null default 'PKR',
  "gateway" text not null,
  "status" "PaymentStatus" not null default 'PENDING',
  "transactionRef" text,
  "createdAt" timestamp(3) not null default current_timestamp
);
create index "Payment_userId_idx" on "Payment"("userId");
create index "Payment_courseId_idx" on "Payment"("courseId");
create index "Payment_enrollmentId_idx" on "Payment"("enrollmentId");
create index "Payment_couponId_idx" on "Payment"("couponId");

-- ------------------- BRAND SETTINGS -------------------

create table "BrandSettings" (
  "id" text primary key default gen_random_uuid()::text,
  "tenantId" text not null unique references "Tenant"("id"),
  "academyName" text not null,
  "logoUrl" text,
  "primaryColor" text not null default '#1E40AF',
  "secondaryColor" text not null default '#F59E0B',
  "fontFamily" text not null default 'Inter',
  "heroTitle" text,
  "heroSubtitle" text,
  "heroImageUrl" text,
  "updatedAt" timestamp(3) not null default current_timestamp
);

-- ------------------- CONTENT BLOCK -------------------

create table "ContentBlock" (
  "id" text primary key default gen_random_uuid()::text,
  "tenantId" text references "Tenant"("id"),
  "section" text not null,
  "order" integer not null default 0,
  "title" text,
  "body" text,
  "imageUrl" text,
  "metadata" jsonb,
  "isActive" boolean not null default true,
  "updatedAt" timestamp(3) not null default current_timestamp
);
create index "ContentBlock_tenantId_idx" on "ContentBlock"("tenantId");
create index "ContentBlock_section_idx" on "ContentBlock"("section");

-- ------------------- SUPPORT TICKET -------------------

create table "SupportTicket" (
  "id" text primary key default gen_random_uuid()::text,
  "userId" text not null references "User"("id"),
  "subject" text not null,
  "status" "TicketStatus" not null default 'OPEN',
  "assignedToId" text references "User"("id"),
  "createdAt" timestamp(3) not null default current_timestamp,
  "updatedAt" timestamp(3) not null default current_timestamp
);
create index "SupportTicket_userId_idx" on "SupportTicket"("userId");
create index "SupportTicket_assignedToId_idx" on "SupportTicket"("assignedToId");

-- ------------------- TICKET MESSAGE -------------------

create table "TicketMessage" (
  "id" text primary key default gen_random_uuid()::text,
  "ticketId" text not null references "SupportTicket"("id"),
  "authorId" text not null references "User"("id"),
  "body" text not null,
  "createdAt" timestamp(3) not null default current_timestamp
);
create index "TicketMessage_ticketId_idx" on "TicketMessage"("ticketId");

-- ============================================================
-- Done. 27 tables, 8 enums, all foreign keys and indexes created.
--
-- NEXT STEPS:
-- 1. Seed the first Admin account — see the INSERT template at the
--    bottom of database/supabase-seed-admin.sql (separate file,
--    since it needs a real bcrypt password hash, not plain text).
-- 2. Once you (or a developer) DO have Prisma CLI access on a real
--    machine, run:
--      npx prisma migrate resolve --applied "0_init"
--    against this same database, after creating an empty migration
--    folder named prisma/migrations/0_init/ — this tells Prisma
--    "this migration is already applied, don't try to re-run it,"
--    syncing Prisma's own migration history with what you just did
--    by hand here. Without this step, Prisma will think the database
--    is empty and may try to run migrations that conflict with these
--    already-existing tables.
-- ============================================================
