// Manual Jest mock for '@prisma/client'.
//
// WHY THIS EXISTS: this sandbox's network policy blocks binaries.prisma.sh,
// so `prisma generate` cannot download its query engine and the real
// generated client/types don't exist here. This mock stands in for it
// during unit tests ONLY, so service-layer business logic can be tested
// without a live database.
//
// IMPORTANT: run `pnpm prisma:generate` on a machine with normal internet
// access before running this app for real — that produces the REAL client,
// and this mock folder can be deleted or left in place (Jest only uses it
// for tests, never for `pnpm start:dev`).
//
// Enum values below are copied verbatim from schema.prisma — keep them
// in sync if the schema's enums ever change.

export enum UserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER',
  CAMPUS_MANAGER = 'CAMPUS_MANAGER',
  ADMIN = 'ADMIN',
  SUPPORT = 'SUPPORT',
  FINANCE = 'FINANCE',
}

export enum PricingType {
  MONTHLY = 'MONTHLY',
  LUMP_SUM = 'LUMP_SUM',
}

export enum LessonType {
  VIDEO = 'VIDEO',
  READING = 'READING',
  QUIZ = 'QUIZ',
  ASSIGNMENT = 'ASSIGNMENT',
}

export enum EnrollmentStatus {
  ACTIVE = 'ACTIVE',
  EXPIRED = 'EXPIRED',
  PENDING = 'PENDING',
  TRANSFERRED = 'TRANSFERRED',
}

export enum QuestionType {
  SINGLE_CHOICE = 'SINGLE_CHOICE',
  MULTI_CHOICE = 'MULTI_CHOICE',
  OPEN_ENDED = 'OPEN_ENDED',
}

export enum PaymentStatus {
  PENDING = 'PENDING',
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
  REFUNDED = 'REFUNDED',
}

export enum TransferRequestStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
}

export enum TicketStatus {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  RESOLVED = 'RESOLVED',
  CLOSED = 'CLOSED',
}

// Dummy class — real tests inject their own jest.fn()-based fake instead
// of instantiating this, but it's exported so `import { PrismaClient }`
// doesn't blow up if referenced anywhere.
export class PrismaClient {
  $connect() {}
  $disconnect() {}
  $transaction(arg: any) {
    if (Array.isArray(arg)) return Promise.all(arg);
    return arg(this);
  }
}
