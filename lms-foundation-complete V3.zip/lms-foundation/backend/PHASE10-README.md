# Phase 10 — Testing, Optimization & Deployment

The final phase. This is where the backend gets hardened for production and where deployment (Supabase + Netlify, per your setup) gets wired in.

## What's included

### 1. The critical security fix (closes the gap flagged since Phase 7)

`PaymentProviderService.verifyWebhookSignature` used to always return `true` — anyone could POST a fake "payment succeeded" webhook and get free course access. It's now **real cryptographic verification**:

- `verifyHmacSignature` — generic constant-time HMAC-SHA256 comparison (uses `crypto.timingSafeEqual`, not `===`, to avoid leaking timing information)
- `verifyStripeSignatureHeader` — the **exact real algorithm** Stripe's own SDK uses internally (`t=timestamp,v1=hash` header parsing, signed-payload construction, timestamp tolerance window for replay-attack protection) — no `stripe` package dependency needed, since it's fully documented HMAC
- `verifyGenericWebhookSignature` (JazzCash/Easypaisa) — real HMAC verification when a secret is configured; **fails closed in production** if no secret is set (refuses all webhooks) rather than the old stub's silent "trust everyone"; only falls back to allowing requests through in development, for local testing without real gateway credentials

**Correctness detail that matters:** verification now happens against the **raw request body**, not the re-parsed DTO object — `main.ts` enables `rawBody: true` and the controller reads `req.rawBody`. HMAC signatures are computed over exact bytes; verifying a re-serialized JSON object (different key order/whitespace) would make even a genuine, correctly-signed webhook fail verification. This is a real, common mistake in webhook implementations that this phase avoids.

### 2. Rate limiting

`@nestjs/throttler` wired globally (100 req/min per IP baseline), with a **much stricter override** on `/auth/register`, `/auth/login`, `/auth/forgot-password` (5 req/min) — closes the "no rate-limiting on login/register" gap flagged since Phase 1.

### 3. Security headers

`helmet()` middleware added to `main.ts`.

### 4. Health check endpoints

- `GET /health` — liveness (is the process running)
- `GET /health/ready` — readiness (can it actually reach the database — important for catching a Supabase pooler issue that a plain liveness check would miss)

### 5. Supabase-specific database configuration

`schema.prisma`'s `datasource` block now uses **both** `DATABASE_URL` (pooled, port 6543, for runtime) and `DIRECT_URL` (direct, port 5432, for migrations) — Prisma's officially documented pattern for Supabase, necessary because PgBouncer's transaction-pooling mode doesn't support the prepared statements Prisma's migration engine needs.

### 6. Netlify deployment

- `backend/netlify/functions/api.ts` — wraps the entire NestJS app as one serverless function
- `backend/netlify.toml` — routes `/api/*` to that function, bundles Prisma's engine binary with the function
- **`DEPLOYMENT.md`** (project root) — full walkthrough tailored to your exact stack (Supabase setup → Netlify backend deploy → Netlify frontend deploy → post-deploy checklist), including an honest discussion of Netlify Functions' tradeoffs (cold starts, 10s execution timeout) versus a persistent-process host, so you can make an informed call if traffic grows later

### 7. CI/CD

`.github/workflows/backend-ci.yml` — runs on every push/PR touching `backend/`: install → `prisma generate` (works on GitHub's runners, unlike this sandbox) → type-check → test → build. This is a real merge gate, not just documentation.

### 8. Critical-path integration tests

Every prior phase's tests mock adjacent services as interfaces (e.g. `PaymentsService`'s tests mock `EnrollmentsService.updateStatus` entirely). This phase adds `src/integration/critical-path.spec.ts`, which does something different: it instantiates **real, non-mocked instances** of `PaymentsService`, `EnrollmentsService`, `NotificationsService`, `CouponsService`, and `QuizzesService`, wiring them together exactly as NestJS's DI container would — only `PrismaService` is faked. This proves the actual call contracts between services genuinely match, which per-module unit tests structurally cannot catch (a unit test mocking `EnrollmentsService.updateStatus` would still pass even if the real method's signature or behavior silently changed).

## Testing — the full, honest final report

```
Test Suites: 20 passed, 20 total
Tests:       172 passed, 172 total
```

That's every test written across all 10 phases, run together, all green — plus 3 new integration tests this phase and dedicated coverage for every new Phase 10 addition:

| Suite | New tests this phase | Covers |
|---|---|---|
| `payment-provider.service.spec.ts` | 17 | Real HMAC verify/reject, **tampered-payload rejection** (the exact attack the old stub allowed), Stripe algorithm correctness, **replay-attack timestamp rejection**, malformed-header handling, and the **"fails closed in production" regression test** — proving the new behavior is the opposite of the old "always true" stub |
| `critical-path.spec.ts` | 3 | Full real checkout→webhook→enrollment→notification chain across 3 real service instances; enrollment activation genuinely unlocking quiz access via two real services wired together; a PENDING student genuinely blocked |

**A real bug was caught and fixed during this phase's own testing** — worth walking through since it's a good example of exactly the kind of mistake this whole testing discipline exists to catch:

While writing the integration test, `prisma.enrollment.update` was asserted to have been called after the webhook fired — and it wasn't. Root cause: the test had re-mocked `prisma.payment.update` for the checkout step with a value like `{ id: 'pay-1', transactionRef: '...' }`, and never re-mocked it again before the webhook step. `PaymentsService.markPaymentSuccess()` reads `enrollmentId` off whatever `payment.update()` returns to decide whether to activate the enrollment — since the stale mock didn't include `enrollmentId`, the real code **correctly and silently skipped** the enrollment activation, exactly as it should when a payment record genuinely has no linked enrollment. This was a test-setup bug, not a service bug, but finding it required actually running the flow — a purely mocked-at-every-boundary test would never have surfaced it, because each individual mock would have "worked" in isolation.

## Deployment — see DEPLOYMENT.md

Full step-by-step guide is in the project root (`DEPLOYMENT.md`), covering:
1. Supabase database setup (pooled + direct connection strings)
2. Backend deploy to Netlify as a serverless function
3. Frontend deploy to Netlify (once built)
4. Post-deploy checklist, including the specific step of setting real webhook secrets before going live

**Read the tradeoffs section in DEPLOYMENT.md before committing to this architecture long-term** — Netlify Functions work fine for an MVP/launch, but NestJS is fundamentally a persistent-server framework, and if the academy's traffic grows meaningfully, migrating the backend (only) to a persistent-process host (Railway/Render/Fly.io) is the natural next step, with the frontend staying on Netlify.

## What to verify before considering this production-ready

- [ ] Every prior phase's checklist item (this phase doesn't replace those — it hardens what they built)
- [ ] `verifyStripeSignatureHeader` rejects a genuinely tampered payload even with a structurally valid signature header (tested — but re-verify against a real Stripe CLI test webhook once you have real credentials)
- [ ] Rate limiting actually kicks in — hit `/auth/login` 6 times in a minute and confirm the 6th request is rejected
- [ ] `GET /health/ready` correctly reports `disconnected` if you deliberately break the Supabase connection string, not just always `ok`
- [ ] A real deploy to Netlify (backend) succeeds and `/api/health` responds — this sandbox cannot verify this step; it must be done on your machine/Netlify account
- [ ] All payment gateway webhook secrets are set as real values in Netlify's environment variables before connecting live payment gateways — do not go live with `verifyGenericWebhookSignature`'s development fallback still active

## What this project has NOT done (scope honesty, one more time)

This entire 10-phase project has been **backend only**. No Next.js frontend, no admin dashboard UI, no student portal UI has been built — Phase 0's monorepo structure (`apps/web`) and a couple of reference files (`frontend/theme/tokens.css`, `frontend/theme/applyBrandSettings.ts`) are all that exist on the frontend side. "Mobile responsiveness check" and "frontend performance optimization" from the original Phase 10 roadmap item genuinely don't apply yet — those become real once frontend development starts, which was always noted as the next major workstream after this backend foundation.

## Known gaps carried forward (the honest running list)

Every phase flagged known gaps — the ones still open at the end of Phase 10:

- **External integrations are still placeholders**: Bunny.net video (Phase 2), Zoom (Phase 5), JazzCash/Easypaisa/Stripe checkout session creation (Phase 7) all return realistically-shaped mock responses, not real API calls. Webhook *verification* is now real (this phase); webhook *sending* from the gateway side still needs real credentials to test against.
- **No PDF invoice generation** (Phase 7) — invoices are structured JSON.
- **No versioned theme drafts** (Phase 9) — preview is stateless.
- **No email/SMS/WhatsApp delivery** (Phase 6) — notifications are in-app only; `NotificationsService.create()` is the one choke point to wire real delivery later.
- **No campus-scoped admin reporting** (Phase 8) — all reports are academy-wide, Admin-only.

None of these block a genuine MVP launch with real students paying real money for real courses — they're the natural next round of work once the platform is live and real usage clarifies which integrations matter most.

## What's next

The backend foundation — all 10 phases — is complete. **Frontend development (Next.js) is the next major workstream**, building the actual student portal, admin panel UI, and marketing site that consume every API endpoint built across these 10 phases.
